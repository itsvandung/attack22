> I am not responsible for your actions. By downloading software from this repository, you agree to follow the law.

---

#### Features
- [x] Fast spam
- [x] No need to drive your mail
- [x] Supported on python3
- [x] Supported other systems
- [x] Quickly and clearly
- [x] More supported services
- [x] Functionality

----
# Guide on how to use these tool

1. Install Python from

2. Download the repo as a ZIP

3. Go in your file explorer and extract the ZIP file

4. Go in the extracted folder and open the start.bat file

5. Enjoy!

-----

#### If there are problems then look down there will be if failed to download.

<details id="missing-code-coverage">
  <summary>Need Help</summary>

#### Do you need help? Write me on: developer.mishakorzhik@gmail.com
#### And I will consider your letter and problem!

```bash
Emails:
 developer.mishakorzhik@gmail.com

Developers:
 mishakorzhik
```

## Bug?
If the tool fails, follow these steps:

1. Take a screenshot and see the error 
   in detail

2. Contact me through the following 
   email: developer.mishakorzhik@gmail.com

3. Submit the screenshot and explain 
   your problem with that error

</details>

-------

**Repository Views** ![Views](https://profile-counter.glitch.me/EmailSpammer/count.svg)

## Screenshot

#### here you can see a screenshot of Email-Spammer
<br>
<p align="center">
<img width="49.1%" src="https://raw.githubusercontent.com/mishakorzik/Email-Spammer/main/src/IMG_20211018_221028.jpg"/> 
  <img width="49.1%" src="https://raw.githubusercontent.com/mishakorzik/Email-Spammer/main/src/IMG_20211018_221205.jpg"/> 
  <img width="49.1%" src="https://raw.githubusercontent.com/mishakorzik/Email-Spammer/main/src/IMG_20211018_221358.jpg"/> 
<img width="49.1%" src="https://raw.githubusercontent.com/mishakorzik/Email-Spammer/main/src/IMG_20211018_221605.jpg"/>
</p>
