import os
import sys

os.system("cd && rm -rf AutoUpdateMyTools")
os.system("cd && git clone https://github.com/mishakorzik/AutoUpdateMyTools && cd AutoUpdateMyTools && bash Update-Email-Spammer.sh")
